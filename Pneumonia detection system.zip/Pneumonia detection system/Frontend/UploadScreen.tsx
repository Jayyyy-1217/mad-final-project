// Import statements
import React, { useState } from 'react';
import { View, Image, Text, StyleSheet, TouchableOpacity, Modal } from 'react-native';
import { launchImageLibrary } from 'react-native-image-picker';
import axios from 'axios';

// UploadScreen component
const UploadScreen = ({ setOnUploadPage }) => {
  const [imageUri, setImageUri] = useState(null);
  const [loading, setLoading] = useState(false);
  const [prediction, setPrediction] = useState(null);
  const [confidence, setConfidence] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [mildErrorModalVisible, setMildErrorModalVisible] = useState(false);

  const pickImage = () => {
    launchImageLibrary(
      {
        mediaType: 'photo',
        includeBase64: false,
        quality: 1,
      },
      (response) => {
        if (response.didCancel || response.errorCode) {
          setMildErrorModalVisible(true);
        } else {
          const uri = response.assets[0].uri;
          setImageUri(uri);
        }
      }
    );
  };

  const uploadImage = async () => {
    const formData = new FormData();
    formData.append('file', {
      uri: imageUri,
      name: 'photo.jpg',
      type: 'image/jpeg',
    });

    try {
      setLoading(true);

      const response = await axios.post('http://10.0.2.2:5000/predict', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      setPrediction(response.data.prediction);
      setConfidence(response.data.confidence.toFixed(2));
      setModalVisible(true);
    } catch (error) {
      console.error(error);
      setMildErrorModalVisible(true); // Show mild error modal on error
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.uploadContainer}>
      <Text style={styles.uploadTitle}>Upload an image of your X-ray to find your condition</Text>
      <TouchableOpacity style={styles.button} onPress={pickImage}>
        <Text style={styles.buttonText}>Select an Image</Text>
      </TouchableOpacity>
      {imageUri && <Image source={{ uri: imageUri }} style={styles.image} />}

      {imageUri && (
  <TouchableOpacity style={styles.confirmButton} onPress={uploadImage} disabled={loading}>
    <Text style={styles.confirmButtonText}>Confirm Upload</Text>
  </TouchableOpacity>
)}


      <TouchableOpacity style={styles.backButton} onPress={() => setOnUploadPage(false)}>
        <Text style={styles.backButtonText}>Go Back</Text>
      </TouchableOpacity>

      {loading && <Text style={styles.loadingText}>Uploading...</Text>}

      {/* Modal for displaying prediction results */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>
              {prediction === 'Normal' ? '🎉 Condition: Normal' : '⚠️ Condition: Pneumonic'}
            </Text>
            <Text style={styles.modalAdviceText}>
              {prediction === 'Normal' ? 'Great news! You are healthy!' : 'Please consult a doctor for further evaluation.'}
            </Text>
            <Text style={styles.modalConfidenceText}>
              Confidence Level: {confidence}%
            </Text>
            <TouchableOpacity style={styles.modalButton} onPress={() => setModalVisible(false)}>
              <Text style={styles.modalButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Mild Error Modal for errors */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={mildErrorModalVisible}
        onRequestClose={() => setMildErrorModalVisible(false)}
      >
        <View style={styles.mildErrorModalContainer}>
          <View style={styles.mildErrorModalContent}>
            <Text style={styles.mildErrorModalTitle}>Oops!</Text>
            <Text style={styles.mildErrorModalText}>
              Please upload an image
            </Text>
            <TouchableOpacity
              style={styles.mildErrorModalButton}
              onPress={() => setMildErrorModalVisible(false)}
            >
              <Text style={styles.mildErrorModalButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

// Styles for the UploadScreen component
const styles = StyleSheet.create({
  uploadContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#e0f7fa',
  },
  uploadTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
    color: '#004d40',
  },
  image: {
    width: 220,
    height: 220,
    marginTop: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#004d40',
  },
  confirmButton: {
    backgroundColor: '#00796b',
    paddingVertical: 8,
    paddingHorizontal: 25,
    borderRadius: 25,
    elevation: 4,
    marginTop: 15,
  },
  confirmButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  button: {
    backgroundColor: '#00897b',
    paddingVertical: 10,
    paddingHorizontal: 35,
    borderRadius: 30,
    elevation: 4,
    marginTop: 15,
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  backButton: {
    backgroundColor: '#dc3545',
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 30,
    elevation: 4,
    marginTop: 15,
  },
  backButtonText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  loadingText: {
    marginTop: 15,
    color: '#FFA500',
    fontStyle: 'italic',
    fontSize: 16,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
  },
  modalContent: {
    width: '80%',
    padding: 25,
    borderRadius: 12,
    backgroundColor: '#ffffff',
    borderWidth: 1.5,
    borderColor: '#00897b',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.3,
    shadowRadius: 2,
    elevation: 6,
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#28A745',
    textAlign: 'center',
    marginBottom: 12,
  },
  modalAdviceText: {
    fontSize: 18,
    color: '#FF9800',
    textAlign: 'center',
    marginVertical: 8,
  },
  modalConfidenceText: {
    fontSize: 18,
    color: '#004d40',
    fontWeight: 'bold',
  },
  modalButton: {
    marginTop: 20,
    backgroundColor: '#00897b',
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 30,
    elevation: 3,
  },
  modalButtonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  mildErrorModalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
  },
  mildErrorModalContent: {
    width: '80%',
    padding: 25,
    borderRadius: 12,
    backgroundColor: '#ffe6e6',
    borderWidth: 1,
    borderColor: '#dc3545',
    alignItems: 'center',
    elevation: 6,
  },
  mildErrorModalTitle: {
    fontSize: 25,
    fontWeight: 'bold',
    color: '#b71c1c', 
    textAlign: 'center',
    marginBottom: 12,
  },
  mildErrorModalText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333333', 
    textAlign: 'center',
    marginVertical: 4,
  },
  mildErrorModalButton: {
    marginTop: 20,
    backgroundColor: '#dc3545',
    paddingVertical: 8,
    paddingHorizontal: 22,
    borderRadius: 30,
    elevation: 2,
  },
  mildErrorModalButtonText: {
    color: '#ffffff',
    fontSize: 15,
    fontWeight: 'bold',
  },
});

export default UploadScreen;
