// HomeScreen.js
import React from 'react';
import { View, Image, Text, StyleSheet, TouchableOpacity } from 'react-native';

const HomeScreen = ({ navigateToUpload }) => {
  return (
    <View style={styles.container}>
      <Image
        source={require('./assets/lungslogo.png')}// Update with your logo path
        style={styles.logo}
      />
      <Text style={styles.title}>Check for Pneumonia</Text>
      <Text style={styles.subtitle}>Use our AI to analyze your X-ray!</Text>
      <TouchableOpacity style={styles.button} onPress={navigateToUpload}>
        <Text style={styles.buttonText}>Check Now</Text>
      </TouchableOpacity>
    </View>
  );
};

// Styles for the HomeScreen component
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#e0f7fa', // Light cyan background
  },
  logo: {
    width: 200,
    height: 150,
    marginBottom: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#006064', // Dark cyan color
  },
  subtitle: {
    fontSize: 18,
    marginBottom: 30,
    color: '#004d40', // Dark green color
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#00796b', // Teal color
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 30,
    elevation: 4,
  },
  buttonText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },
});

export default HomeScreen;
