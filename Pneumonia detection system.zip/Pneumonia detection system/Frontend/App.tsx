// App.js
import React, { useState } from 'react';
import { SafeAreaView } from 'react-native';
import HomeScreen from './HomeScreen';
import UploadScreen from './UploadScreen';

const App = () => {
  const [onUploadPage, setOnUploadPage] = useState(false);

  const navigateToUpload = () => {
    setOnUploadPage(true);
  };

  return (
    <SafeAreaView style={{ flex: 1 }}>
      {onUploadPage ? <UploadScreen setOnUploadPage={setOnUploadPage} /> : <HomeScreen navigateToUpload={navigateToUpload} />}
    </SafeAreaView>
  );
};

export default App;
