from flask import Flask, request, jsonify
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np
import os

# Initialize the Flask app
app = Flask(__name__)

# Load the model
model_path = 'model/pneumonia_detection_model.keras'
model = load_model(model_path)

# Define the image size
img_width, img_height = 150, 150

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    file = request.files['file']  
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    img_path = os.path.join('uploads', file.filename)
    file.save(img_path)

    img = image.load_img(img_path, target_size=(img_width, img_height))
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0) / 255.0 
    prediction = model.predict(img_array)
    os.remove(img_path) 
    result = 'Pneumonia' if prediction[0][0] > 0.5 else 'Normal' 
    return jsonify({'prediction': result, 'confidence': float(prediction[0][0])})

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
